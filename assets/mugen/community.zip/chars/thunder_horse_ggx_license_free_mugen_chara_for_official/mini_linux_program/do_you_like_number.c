#include <stdio.h>

main()
{
	int x1 = 100;
	printf("Do you like number?1-9");
	int c = getchar();
	switch(c)
		{
		case '1':
		printf("You select :%d",1);
		printf("You are Powerfull");
			break;
		case '2':
		printf("You select :%d",2);
		printf("You are Kind");
			break;
		case '3':
		printf("You select :%d",3);
		printf("You are Funny");
			break;
		case '4':
		printf("You select :%d",4);
		printf("You are American");
			break;
		case '5':
		printf("You select :%d",5);
		printf("You like child?");
			break;
		case '6':
		printf("You select :%d",6);
		printf("You like Devil");
			break;
		case '7':
		printf("You select :%d",7);
		printf("You may be Unlucky");
			break;
		case '8':
		printf("You select :%d",8);
		printf("You like Power");
			break;
		case '9':
		printf("You select :%d",9);
		printf("You like Last");
			break;
		case '0':
		printf("You select :%d",0);
		printf("You are Negative");
			break;
		default:
			printf("%d",x1);
			break;
		}
}
