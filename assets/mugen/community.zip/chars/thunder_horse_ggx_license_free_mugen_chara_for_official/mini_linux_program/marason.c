#include <stdio.h>

main()
{
	int flag;
	int x1 = 0;
	int x2 = 1;
	while(1){
		int c = getchar();
		if(c==10){
		x1=x1+1;
		if(x1==1){
		printf("stage %d\n",x2);
		printf("O_________\n");
		printf("==========");
		}else if(x1==2){
		printf("_O________\n");
		printf("==========");
		}else if(x1==3){
		printf("__O_______\n");
		printf("==========");
		}else if(x1==4){
		printf("___O______\n");
		printf("==========");
		}else if(x1==5){
		printf("____O_____\n");
		printf("==========");
		}else if(x1==6){
		printf("_____O____\n");
		printf("==========");
		}else if(x1==7){
		printf("______O___\n");
		printf("==========");
		}else if(x1==8){
		printf("_______O__\n");
		printf("==========");
		}else if(x1==9){
		printf("________O_\n");
		printf("==========");
		}else if(x1==10){
		printf("_________O\n");
		printf("==========");
		x2=x2+1;
		x1=0;
		}
		}
	}
}
