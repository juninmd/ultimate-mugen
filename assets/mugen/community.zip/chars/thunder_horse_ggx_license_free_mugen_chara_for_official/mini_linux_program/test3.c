#include <stdio.h>

main()
{
	int u1=0;
	int a11 = 2;
	int a12 = 0;
	int a13 = 0;
	int a21 = 2;
	int a22 = 0;
	int a23 = 0;
	int a31 = 2;
	int a32 = 0;
	int a33 = 0;
	int j1 = 1;
	int j2 = 0;
	int j3 = 0;
	int j4 = 0;
	int j5 = 0;
	int j6 = 0;
	int j7 = 0;
	int j8 = 0;
	int j9 = 0;
	int j1tama11 = 0;
	int j1tama12 = 0;
	int j1tama13 = 0;
	int j1tama14 = 0;
	int j1tama15 = 0;
	int j1tama16 = 0;
	int j1tama17 = 0;
	int j1tama18 = 0;
	int j1tama19 = 0;
	int j1tama21 = 0;
	int j1tama22 = 0;
	int j1tama23 = 0;
	int j1tama24 = 0;
	int j1tama25 = 0;
	int j1tama26 = 0;
	int j1tama27 = 0;
	int j1tama28 = 0;
	int j1tama29 = 0;
	int j1tama31 = 0;
	int j1tama32 = 0;
	int j1tama33 = 0;
	int j1tama34 = 0;
	int j1tama35 = 0;
	int j1tama36 = 0;
	int j1tama37 = 0;
	int j1tama38 = 0;
	int j1tama39 = 0;
	int j1tama41 = 0;
	int j1tama42 = 0;
	int j1tama43 = 0;
	int j1tama44 = 0;
	int j1tama45 = 0;
	int j1tama46 = 0;
	int j1tama47 = 0;
	int j1tama48 = 0;
	int j1tama49 = 0;
	int j1tama51 = 0;
	int j1tama52 = 0;
	int j1tama53 = 0;
	int j1tama54 = 0;
	int j1tama55 = 0;
	int j1tama56 = 0;
	int j1tama57 = 0;
	int j1tama58 = 0;
	int j1tama59 = 0;
	int a1live = 1;
	int a2live = 1;
	int a3live = 1;
	int flag = 1;
	int jx1 = 1;
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",a11,a11,a12,a12,a13,a13,a21,a21,a22,a22,a23,a23,a31,a31,a32,a32,a33,a33);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama51,j1tama51,j1tama52,j1tama52,j1tama53,j1tama53,j1tama54,j1tama54,j1tama55,j1tama55,j1tama56,j1tama56,j1tama57,j1tama57,j1tama58,j1tama58,j1tama59,j1tama59);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama41,j1tama41,j1tama42,j1tama42,j1tama43,j1tama43,j1tama44,j1tama44,j1tama45,j1tama45,j1tama46,j1tama46,j1tama47,j1tama47,j1tama48,j1tama48,j1tama49,j1tama49);
	printf("");printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama31,j1tama31,j1tama32,j1tama32,j1tama33,j1tama33,j1tama34,j1tama34,j1tama35,j1tama35,j1tama36,j1tama36,j1tama37,j1tama37,j1tama38,j1tama38,j1tama39,j1tama39);
	printf("");printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama21,j1tama21,j1tama22,j1tama22,j1tama23,j1tama23,j1tama24,j1tama24,j1tama25,j1tama25,j1tama26,j1tama26,j1tama27,j1tama27,j1tama28,j1tama28,j1tama29,j1tama29);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama11,j1tama11,j1tama12,j1tama12,j1tama13,j1tama13,j1tama14,j1tama14,j1tama15,j1tama15,j1tama16,j1tama16,j1tama17,j1tama17,j1tama18,j1tama18,j1tama19,j1tama19);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1,j1,j2,j2,j3,j3,j4,j4,j5,j5,j6,j6,j7,j7,j8,j8,j9,j9);
	printf("Left 4 Right 6 shot 8");
	while(flag){
	int c = getchar();
	switch(c)
		{
		case '6':
			if(jx1<=8){
			jx1 = jx1 + 1;
			}
			break;
		case '4':
			if(jx1>=2){
			jx1 = jx1 - 1;
			}
			break;
		case '8':
			if(jx1>=2){
			jx1 = jx1 - 1;
			}
			break;
		default:
			break;
		}
	if(jx1==1){
	j1 = 1;
	j2 = 0;
	j3 = 0;
	j4 = 0;
	j5 = 0;
	j6 = 0;
	j7 = 0;
	j8 = 0;
	j9 = 0;
	}else if(jx1==2){
	j1 = 0;
	j2 = 1;
	j3 = 0;
	j4 = 0;
	j5 = 0;
	j6 = 0;
	j7 = 0;
	j8 = 0;
	j9 = 0;
	}else if(jx1==3){
	j1 = 0;
	j2 = 0;
	j3 = 1;
	j4 = 0;
	j5 = 0;
	j6 = 0;
	j7 = 0;
	j8 = 0;
	j9 = 0;
	}else if(jx1==4){
	j1 = 0;
	j2 = 0;
	j3 = 0;
	j4 = 1;
	j5 = 0;
	j6 = 0;
	j7 = 0;
	j8 = 0;
	j9 = 0;
	}else if(jx1==5){
	j1 = 0;
	j2 = 0;
	j3 = 0;
	j4 = 0;
	j5 = 1;
	j6 = 0;
	j7 = 0;
	j8 = 0;
	j9 = 0;
	}else if(jx1==6){
	j1 = 0;
	j2 = 0;
	j3 = 0;
	j4 = 0;
	j5 = 0;
	j6 = 1;
	j7 = 0;
	j8 = 0;
	j9 = 0;
	}else if(jx1==7){
	j1 = 0;
	j2 = 0;
	j3 = 0;
	j4 = 0;
	j5 = 0;
	j6 = 0;
	j7 = 1;
	j8 = 0;
	j9 = 0;
	}else if(jx1==8){
	j1 = 0;
	j2 = 0;
	j3 = 0;
	j4 = 0;
	j5 = 0;
	j6 = 0;
	j7 = 0;
	j8 = 1;
	j9 = 0;
	}else if(jx1==9){
	j1 = 0;
	j2 = 0;
	j3 = 0;
	j4 = 0;
	j5 = 0;
	j6 = 0;
	j7 = 0;
	j8 = 0;
	j9 = 1;
	}
	u1=u1+1;
	if(u1==4){
	u1=0;
	}else if(u1 == 0){
	a11 = 2;
	a12 = 0;
	a13 = 0;
	a21 = 2;
	a22 = 0;
	a23 = 0;
	a31 = 2;
	a32 = 0;
	a33 = 0;
	}else if(u1 == 1){
	a11 = 0;
	a12 = 2;
	a13 = 0;
	a21 = 0;
	a22 = 2;
	a23 = 0;
	a31 = 0;
	a32 = 2;
	a33 = 0;
	}else if(u1 == 2){
	a11 = 0;
	a12 = 0;
	a13 = 2;
	a21 = 0;
	a22 = 0;
	a23 = 2;
	a31 = 0;
	a32 = 0;
	a33 = 2;
	}else if(u1 == 3){
	a11 = 0;
	a12 = 2;
	a13 = 0;
	a21 = 0;
	a22 = 2;
	a23 = 0;
	a31 = 0;
	a32 = 2;
	a33 = 0;
	}
	printf("\n%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",a11,a11,a12,a12,a13,a13,a21,a21,a22,a22,a23,a23,a31,a31,a32,a32,a33,a33);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama51,j1tama51,j1tama52,j1tama52,j1tama53,j1tama53,j1tama54,j1tama54,j1tama55,j1tama55,j1tama56,j1tama56,j1tama57,j1tama57,j1tama58,j1tama58,j1tama59,j1tama59);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama41,j1tama41,j1tama42,j1tama42,j1tama43,j1tama43,j1tama44,j1tama44,j1tama45,j1tama45,j1tama46,j1tama46,j1tama47,j1tama47,j1tama48,j1tama48,j1tama49,j1tama49);
	printf("");printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama31,j1tama31,j1tama32,j1tama32,j1tama33,j1tama33,j1tama34,j1tama34,j1tama35,j1tama35,j1tama36,j1tama36,j1tama37,j1tama37,j1tama38,j1tama38,j1tama39,j1tama39);
	printf("");printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama21,j1tama21,j1tama22,j1tama22,j1tama23,j1tama23,j1tama24,j1tama24,j1tama25,j1tama25,j1tama26,j1tama26,j1tama27,j1tama27,j1tama28,j1tama28,j1tama29,j1tama29);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1tama11,j1tama11,j1tama12,j1tama12,j1tama13,j1tama13,j1tama14,j1tama14,j1tama15,j1tama15,j1tama16,j1tama16,j1tama17,j1tama17,j1tama18,j1tama18,j1tama19,j1tama19);
	printf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d\n",j1,j1,j2,j2,j3,j3,j4,j4,j5,j5,j6,j6,j7,j7,j8,j8,j9,j9);
	printf("Left 4 Right 6 shot 8");
	printf("%d",u1);
	printf("%d",a11);
	}
	flag = 1;
}
