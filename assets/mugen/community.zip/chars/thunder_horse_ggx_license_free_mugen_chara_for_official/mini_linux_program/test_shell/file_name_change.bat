#!/bin/sh
	echo -n "Change your file"
	echo
	read name1
	echo -n "Type newname"
	echo
	read newname
	mv "$name1" "$newname"
