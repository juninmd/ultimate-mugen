@echo off
echo "use custom ls"
ls -l
pause
