Babaru_GGX character
---------------------
This chara is similar GG.
You use this chara free.

  Controls
  --------

    Basic Controls
    --------------
      D - down
      F - forward
      U - up
      B - back
      x - button X (weak punch)
      y - button Y (strong punch)

    Standard Movement
    -----------------
      U              - Jump
      UF             - Jump forwards
      F              - Walk forwards
      DF             - Crouch
      D              - Crouch
      DB             - Crouch or low guard
      B              - Walk backwards or high guard
      UB             - Jump back
      F, F           - Forward dash
      B, B           - Back dash
      xy             - Recovery (when falling)

    Basic Standing Attacks
    ----------------------
      X              - W. Punch
      Y              - S. Punch

    Basic Crouching Attacks
    -----------------------
      X              - Low W. Punch
      Y              - Low S. Punch

    Basic Air Attacks
    -----------------
      X              - Air W. Punch
      Y              - Air S. Punch

    Special Attacks
    ---------------
      D, DF, F + x   - KFM Punch

      D, DF, F, D, DF, F + x   - Itai Leg

      Start  - ?